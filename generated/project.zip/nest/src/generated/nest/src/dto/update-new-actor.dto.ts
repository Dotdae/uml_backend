// generated/nest/src/dto/update-new-actor.dto.ts
import { PartialType } from '@nestjs/swagger';
import { CreateNewActorDto } from './create-new-actor.dto';

export class UpdateNewActorDto extends PartialType(CreateNewActorDto) {}