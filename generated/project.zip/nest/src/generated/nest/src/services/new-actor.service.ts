// generated/nest/src/services/new-actor.service.ts
import { Injectable } from '@nestjs/common';

@Injectable()
export class NewActorService {
  async getNewActor(): Promise<string> {
    return 'GET /newactor - action: auto-generated';
  }

  async getNewActorAgain(): Promise<string> {
    return 'GET /newactor - action: auto-generated';
  }
}