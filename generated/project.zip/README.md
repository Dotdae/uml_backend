# Generated Project

This project contains both NestJS backend and Angular frontend code generated from UML diagrams.

## Structure
- /nest - NestJS backend code
  - /src
    - /controllers - REST API controllers
    - /services - Business logic
    - /entities - Database models
    - /dtos - Data transfer objects
    - /modules - NestJS modules
- /angular - Angular frontend code
  - /src
    - /app
      - /components - Angular components
      - /services - Angular services
      - /models - TypeScript interfaces

## Getting Started

1. Install all dependencies:
   ```bash
   npm run install:all
   ```

2. Start the servers:
   - NestJS: `npm run start:nest`
   - Angular: `npm run start:angular`

3. Access the applications:
   - NestJS API: http://localhost:3000
   - Angular Frontend: http://localhost:4200

## Development

- Build both projects:
  ```bash
  npm run build:all
  ```

- Run tests:
  ```bash
  npm run test:all
  ```

## Project Structure

### NestJS Backend
- Controllers handle HTTP requests and define API endpoints
- Services contain business logic
- Entities define database models
- DTOs validate request/response data
- Modules organize and configure the application

### Angular Frontend
- Components handle UI elements and user interaction
- Services manage data and communicate with the backend
- Models define TypeScript interfaces for type safety
