# Generated Project

This project contains both NestJS backend and Angular frontend code generated from UML diagrams.

## Structure
- /nest - NestJS backend code
  - /src
    - /controllers - REST API controllers
    - /services - Business logic
    - /entities - Database models
    - /dtos - Data transfer objects
    - /modules - NestJS modules
- /angular - Angular frontend code
  - /src
    - /app
      - /components - Angular components
      - /services - Angular services
      - /models - TypeScript interfaces

## Getting Started
1. Install all dependencies:
   ```bash
   npm run install:all
   ```

2. Start the servers:
   - NestJS: `npm run start:nest`
   - Angular: `npm run start:angular`

## Generated Files
The project structure follows standard NestJS and Angular conventions:

### NestJS
- Controllers handle HTTP requests
- Services contain business logic
- Entities define database models
- DTOs validate request/response data
- Modules organize application structure

### Angular
- Components handle UI presentation
- Services manage data and API calls
- Models define TypeScript interfaces
