// src/usuario/interfaces/usuario.interface.ts
export interface Usuario {
  id: number;
  username: string;
  email: string;
}